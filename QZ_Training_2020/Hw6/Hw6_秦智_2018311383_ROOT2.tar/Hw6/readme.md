## Hw6-ROOT2

### T1-2

两道题一起做了

直接看结果：

```shell

root -l
root [0] .L MakeClass_t3.C
root [1] MakeClass_t3 t3
root [2] t3.Loop()

```


完整步骤：

- ex42.C
  - ex42.root
  - c1.png

- 通过ex42.root的t3运用MakeClass工具生成MakeClass_t3.c(h)

- 编辑MakeClass_t3.c(h)
  - ex42_p_tot.png
  - ex42_p_tot-2.png（两种理解）
  - sort.png
