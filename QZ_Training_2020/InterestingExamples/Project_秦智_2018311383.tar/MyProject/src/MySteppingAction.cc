//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
/// \file MySteppingAction.cc
/// \brief Implementation of the MySteppingAction class

#include "MySteppingAction.hh"
#include "MyEventAction.hh"
#include "MyRunAction.hh"
#include "MyDetectorConstruction.hh"

#include "G4Step.hh"
#include "G4Event.hh"
#include "G4RunManager.hh"
#include "G4LogicalVolume.hh"

#include "G4UnitsTable.hh"
#include "G4SystemOfUnits.hh"

#include <string>

#include "g4root.hh"
#include "MyPrimaryGeneratorAction.hh"

extern MySimMode_t My_Sim_mode;

// #include <iostream>

using namespace std;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

MySteppingAction::MySteppingAction(MyEventAction* eventAction)
: G4UserSteppingAction(),
  fEventAction(eventAction),
  fSDVolume(0)
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

MySteppingAction::~MySteppingAction()
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void MySteppingAction::UserSteppingAction(const G4Step* step)
{
  if (!fSDVolume) {
    const MyDetectorConstruction* detectorConstruction
      = static_cast<const MyDetectorConstruction*>
        (G4RunManager::GetRunManager()->GetUserDetectorConstruction());
    fSDVolume = detectorConstruction->GetSDVolume();
  }

  if(fEventAction->fRunAction->iflog){
    logstepinfo(step);
  }

  // get volume of the current step
  G4LogicalVolume* volume
    = step->GetPreStepPoint()->GetTouchableHandle()
      ->GetVolume()->GetLogicalVolume();

  // check if we are in sensitive detector volume
  if (volume != fSDVolume) return;


  switch(My_Sim_mode)
  {
    case NEUTRINO:
      // 判断parentid=1,种类为反电子中微子，（否则不再模拟）。记录中微子能量，并设为已记录，此event不再增加能量
      if(fEventAction->fEdep_sign==1){
        if(step->GetTrack()->GetParentID()==1&&(step->GetTrack()->GetDynamicParticle()->GetDefinition()->GetParticleName())=="anti_nu_e"){
          G4double edepStep = step->GetPreStepPoint()->GetTotalEnergy();
          edepStep = edepStep - 0.784*MeV;
          fEventAction->AddEdep(edepStep);
          // step->GetTrack()->SetTrackStatus(fPostponeToNextEvent);
          step->GetTrack()->SetTrackStatus(fStopAndKill);
          fEventAction->fEdep_sign = 0;
        }
      }
      if(fEventAction->fEdep_sign==0){
          // step->GetTrack()->SetTrackStatus(fStopAndKill);
          step->GetTrack()->SetTrackStatus(fKillTrackAndSecondaries);
      }
      break;
    case NEUTRON:
      // 判断粒子为质子，则记录质子动能，并加入此event能量
      if(fEventAction->fEdep_sign==1){
        if((step->GetTrack()->GetDynamicParticle()->GetDefinition()->GetParticleName())=="proton"){
          G4double edepStep = step->GetPreStepPoint()->GetKineticEnergy();
          fEventAction->AddEdep(edepStep/10);
          // step->GetTrack()->SetTrackStatus(fStopAndKill);
          step->GetTrack()->SetTrackStatus(fKillTrackAndSecondaries);
        }
      }
      break;
    case OTHER:
      break;
  }


  //G4AnalysisManager FillH1
  // G4AnalysisManager* analysis = G4AnalysisManager::Instance();
  // analysis->FillH1(0, edepStep);



}

void MySteppingAction::logstepinfo(const G4Step* step)
{

  G4LogicalVolume* prevolume
    = step->GetPreStepPoint()->GetTouchableHandle()->GetVolume()->GetLogicalVolume();
  G4LogicalVolume* postvolume
    = step->GetPreStepPoint()->GetTouchableHandle()->GetVolume()->GetLogicalVolume();
  G4String prevolumename = prevolume->GetName();
  G4String postvolumename = postvolume->GetName();
  G4double edepStep = step->GetTotalEnergyDeposit()/MeV;
  G4double edeltstep = step->GetDeltaEnergy()/MeV;
  G4double steplength = step->GetStepLength()/mm;
  G4int trackid = (step->GetTrack()->GetTrackID());
  G4int parent_trackid = (step->GetTrack()->GetParentID());
  G4int stepnumber = (step->GetTrack()->GetCurrentStepNumber());
  G4String particlename = (step->GetTrack()->GetDynamicParticle()->GetDefinition()->GetParticleName());
  // const G4VProcess* creatorProcess = step->GetTrack()->GetCreatorProcess();
  G4String creatorprocess_name = "Primary";//launched from G4ParticleGun or G4GeneralParticleSource
  //https://hypernews.slac.stanford.edu/HyperNews/geant4/get/eventtrackmanage/919/1.html
  if(step->GetTrack()->GetCreatorProcess()!=0){
    creatorprocess_name = step->GetTrack()->GetCreatorProcess()->GetProcessName();
  }
  G4double trackglobaltime = step->GetTrack()->GetGlobalTime()/ns;
  G4double preglobaltime = step->GetPreStepPoint()->GetGlobalTime()/ns;
  G4double postglobaltime = step->GetPostStepPoint()->GetGlobalTime()/ns;


  G4String logstr = "trackid: "+to_string(trackid)+" \t"+"parent_trackid: "+to_string(parent_trackid)+"stepnumber: "+to_string(stepnumber)+" \t"+"creatorprocess: "+creatorprocess_name+" \t"+"particle_name: "+particlename+" \t"+"prevolumename: "+prevolumename+" \t"+"postvolumename: "+postvolumename+" \t"+"step_edep: "+to_string(edepStep)+"MeV"+" \t"+"step_edelta: "+to_string(edeltstep)+"MeV"+" \t"+"steplength: "+to_string(steplength)+"mm"+"\n";
  logstr = logstr +"trackglobaltime: "+to_string(trackglobaltime)+"ns"+" \t"+"preglobaltime: "+to_string(preglobaltime)+"ns"+" \t"+"postglobaltime: "+to_string(postglobaltime)+"ns"+" \t"+"\n";
  logstr = logstr +
      "PreStepPoint_pos: "+'{' + to_string((step->GetPreStepPoint()->GetPosition().x())/mm) +','
      +to_string((step->GetPreStepPoint()->GetPosition().y())/mm)+','
      +to_string((step->GetPreStepPoint()->GetPosition().z())/mm)+'}'+"mm"+" \t"
	    +"PreStepPoint_GetTotalEnergy:"+to_string(step->GetPreStepPoint()->GetTotalEnergy()/MeV)+"MeV"+" \t"+"PreStepPoint_GetKineticEnergy:"+to_string(step->GetPreStepPoint()->GetKineticEnergy()/MeV)+"MeV"+"\t"+"presteppoint is at fGeomBoundary?: "+to_string(step->GetPreStepPoint()->GetStepStatus() == fGeomBoundary)+"\n";
  logstr = logstr +
      "PostStepPoint_pos: "+'{' + to_string((step->GetPostStepPoint()->GetPosition().x())/mm) +','
      +to_string((step->GetPostStepPoint()->GetPosition().y())/mm)+','
      +to_string((step->GetPostStepPoint()->GetPosition().z())/mm)+'}'+"mm"+" \t"
	    +"PostStepPoint_GetTotalEnergy:"+to_string(step->GetPostStepPoint()->GetTotalEnergy()/MeV)+"MeV"+" \t"+"PostStepPoint_GetKineticEnergy:"+to_string(step->GetPostStepPoint()->GetKineticEnergy()/MeV)+"MeV"+"\n";
  logstr = logstr +
      "DynamicParticle_GetTotalEnergy: "+to_string(step->GetTrack()->GetDynamicParticle()->GetTotalEnergy()/MeV)+"MeV"+" \t"+"DynamicParticle_GetKineticEnergy:"+to_string(step->GetPostStepPoint()->GetKineticEnergy()/MeV)+"MeV"+"\t"+"poststeppoint is at fGeomBoundary?: "+to_string(step->GetPostStepPoint()->GetStepStatus() == fGeomBoundary)+"\n";


  fEventAction->fRunAction->runlogfile<<"<<<<<<<<--------------------------<step----------------------------------"<<G4endl;
  fEventAction->fRunAction->runlogfile<<logstr<<G4endl;
  fEventAction->fRunAction->runlogfile<<"-----------------------------------step>------------------------->>>>>>>>"<<G4endl;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
