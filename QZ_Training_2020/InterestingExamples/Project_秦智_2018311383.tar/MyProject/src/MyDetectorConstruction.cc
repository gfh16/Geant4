//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
/// \file MyDetectorConstruction.cc
/// \brief Implementation of the MyDetectorConstruction class

#include "MyDetectorConstruction.hh"

#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Cons.hh"
#include "G4Orb.hh"
#include "G4Sphere.hh"
#include "G4Trd.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"

#include "G4PhysicalConstants.hh"

#include "G4VisAttributes.hh"
#include "G4Colour.hh"

#define worldSize (30.*m)
#define m_in (5000.*1000*kg)
#define m_out (10000.*1000*kg)
#define rho_LAB (0.863*g/cm3)
#define R_in (std::pow(m_in/(4./3.*M_PI*rho_LAB),1./3.))
#define R_out (std::pow(m_out/(4./3.*M_PI*rho_LAB),1./3.))

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

MyDetectorConstruction::MyDetectorConstruction()
: G4VUserDetectorConstruction(),
  fSDVolume(0)
{
  DefineMaterials();
}

void MyDetectorConstruction::DefineMaterials()
{
  G4NistManager* nist = G4NistManager::Instance();

  G4bool isotopes = false;

  // Define elements
  G4Element*  O = nist->FindOrBuildElement("O" , isotopes);
  G4Element* Si = nist->FindOrBuildElement("Si", isotopes);
  G4Element* Lu = nist->FindOrBuildElement("Lu", isotopes);
  G4Element* Cs = nist->FindOrBuildElement(55,   isotopes);
  G4Element*  I = nist->FindOrBuildElement(53,   isotopes);
  G4Element*  C = nist->FindOrBuildElement("C",  isotopes);
  G4Element*  H = nist->FindOrBuildElement("H",  isotopes);

  G4Material* LSO = new G4Material("Lu2SiO5", 7.4*g/cm3, 3);
  LSO->AddElement(Lu, 2);
  LSO->AddElement(Si, 1);
  LSO->AddElement(O , 5);

  G4Material* CsI = new G4Material("CsI", 3.4079*g/cm3, 2);
  CsI->AddElement(Cs, 1);
  CsI->AddElement(I, 1);

  G4Material* LAB = new G4Material("LAB", rho_LAB, 2);
  LAB->AddElement(C, 18);
  LAB->AddElement(H, 30);

  G4Material* Vacuum = new G4Material("Vacuum", 1.e-30*g/cm3, 1);
  Vacuum->AddElement(H, 1);

  // What about vacuum ?  Vacuum is an ordinary gas with very low density
  G4double density     = universe_mean_density;//from PhysicalConstants.h
  G4double pressure    = 1.e-19*pascal;
  G4double temperature = 0.1*kelvin;
  G4double a,z;
  G4String name;
  new G4Material(name="Galactic", z=1., a=1.01*g/mole, density,kStateGas,temperature,pressure);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

MyDetectorConstruction::~MyDetectorConstruction()
{ }

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4VPhysicalVolume* MyDetectorConstruction::Construct()
{
  G4bool fCheckOverlaps = true;

  // G4LogicalVolumeStore* LVs=G4LogicalVolumeStore::GetInstance();
  G4NistManager* nist = G4NistManager::Instance();

  // Print materials
  G4cout << *(G4Material::GetMaterialTable()) << G4endl;

  G4cout << "worldSize: " << worldSize/m << "m" << G4endl;
  G4cout << "R_in: " << R_in/m << "m" << G4endl;
  G4cout << "R_out: " << R_out/m << "m" << G4endl;

  G4Material* world_mat = nist->FindOrBuildMaterial("G4_AIR");

  // Construct World
  G4Box* solidWorld =
    new G4Box("World",
      0.5*worldSize, 0.5*worldSize, 0.5*worldSize+30.);
  G4LogicalVolume* logicWorld =
    new G4LogicalVolume(solidWorld,
     world_mat,
     // nist->FindOrBuildMaterial("G4_Galactic"),
     "World"); // name
  // LVs->Register(logicWorld);
  G4VPhysicalVolume* physWorld =
    new G4PVPlacement(NULL,//no rotation
      G4ThreeVector(0., 0., 0.), // at origin
      logicWorld,
      "World", //name
      NULL, // mother volume
      false, // no boolean operation
      0, //copy number
      fCheckOverlaps);

  // Construct Outer Sphere
  G4Orb* solidOuter = new G4Orb("Outer", R_out);
  G4LogicalVolume* logicOuter = new G4LogicalVolume(
    solidOuter,
    nist->FindMaterial("LAB"),
    // nist->FindOrBuildMaterial("G4_Galactic"),
    // world_mat,
    "Outer"); //name
  // LVs->Register(logicOuter);
  new G4PVPlacement(NULL,
      G4ThreeVector(0., 0., 0.),
      logicOuter,
      "Outer",
      logicWorld,
      false,
      0, // copy number
      fCheckOverlaps);

  G4Orb* solidInner = new G4Orb("Inner", R_in);
  G4LogicalVolume* logicInner = new G4LogicalVolume(
    solidInner,
    nist->FindMaterial("LAB"),
    // nist->FindMaterial("Galactic"),
    // nist->FindMaterial("Vacuum"),
    // nist->FindOrBuildMaterial("G4_Galactic"),
    // nist->FindOrBuildMaterial("G4_Air"),
    // world_mat,
    "Inner"); //name
  // LVs->Register(logicInner);
  new G4PVPlacement(NULL,
      G4ThreeVector(0., 0., 0.),
      logicInner,
      "Inner",
      logicOuter,
      false,
      0, // copy number
      fCheckOverlaps);

  G4VisAttributes* VisAtt_Inner = new G4VisAttributes(G4Colour(1.0,0.0,0.0,1));
  logicInner -> SetVisAttributes(VisAtt_Inner);

  fSDVolume = logicInner;

  //always return the physical World
  //
  return physWorld;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
