//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
/// \file MyRunAction.cc
/// \brief Implementation of the MyRunAction class

#include "MyRunAction.hh"
#include "MyPrimaryGeneratorAction.hh"
#include "MyDetectorConstruction.hh"
// #include "MyRun.hh"

#include "G4RunManager.hh"
#include "G4Run.hh"
// #include "G4AccumulableManager.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4LogicalVolume.hh"
#include "G4UnitsTable.hh"
#include "G4SystemOfUnits.hh"

#include <ctime>
#include <string>
#include <fstream>
using namespace std;

#include "g4root.hh"

extern MySimMode_t My_Sim_mode;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

MyRunAction::MyRunAction()
: G4UserRunAction()
{

}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

MyRunAction::~MyRunAction()
{
  delete G4AnalysisManager::Instance();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void MyRunAction::BeginOfRunAction(const G4Run*)
{
  // inform the runManager to save random number seed
  G4RunManager::GetRunManager()->SetRandomNumberStore(false);



  // G4int nofEvents = run->GetNumberOfEvent();


  const MyDetectorConstruction* detectorConstruction
   = static_cast<const MyDetectorConstruction*>
     (G4RunManager::GetRunManager()->GetUserDetectorConstruction());
  G4double mass = detectorConstruction->GetSDVolume()->GetMass()/kg;



  time_t now = time(0);
  tm *ltm = localtime(&now);
  G4String fileName = "./data/MySim_"+to_string(1 + ltm->tm_mon)+"_"+to_string(ltm->tm_mday)+"_"+to_string(ltm->tm_hour)+"h_"+to_string(ltm->tm_min)+"m_"+to_string(ltm->tm_sec)+"s";

  if(iflog){
    // time_t now = time(0);
    // tm *ltm = localtime(&now);
    // G4String fileName = "./data/MySim_"+to_string(1 + ltm->tm_mon)+"_"+to_string(ltm->tm_mday)+"_"+to_string(1+ltm->tm_min)+"m_"+to_string(1+ltm->tm_sec)+"s"+".log";
    runlogfile.open(fileName+".log",ios_base::app);
    runlogfile<<"----------------------------Begin of Run-------------------------------------"<<G4endl;
    // runlogfile<<"Number of Events: "<<nofEvents<<G4endl;
    runlogfile<<"SD Detector Mass: "<<mass<<"kg"<<G4endl;
  }
  cout<<"----------------------------Begin of Run-------------------------------------"<<endl;
  cout<<"SD Detector Mass: "<<mass<<"kg"<<endl;


  //G4AnalysisManager  set&begin
  G4AnalysisManager* analysisManager = G4AnalysisManager::Instance();

  G4String id,title;
  G4int nbins,ih;
  G4double value_max,value_min;
  switch(My_Sim_mode)
  {
    case NEUTRINO:
      id = "anti_nu_e";
      title = "anti_nu_e-E";
      value_min = 1;
      value_max = 60;
      nbins = 5*(value_max-value_min);
      // G4String fileName = "./data/MySim_"+to_string(1 + ltm->tm_mon)+"_"+to_string(ltm->tm_mday)+"_"+to_string(ltm->tm_hour)+"h_"+to_string(ltm->tm_min)+"m_"+to_string(ltm->tm_sec)+"s";
      analysisManager->SetFileName(fileName+"_anti_nu_e.root");
      cout<<fileName+"_anti_nu_e.root Open"<<endl;
      analysisManager->SetVerboseLevel(1);
      analysisManager->SetActivation(true);  //enable inactivation of histograms
      ih = analysisManager->CreateH1(id, title, nbins, value_min, value_max);
      analysisManager->SetH1Activation(ih, true);
      break;
    case NEUTRON:
      id = "neutron";
      title = "neutron-E";
      value_min = 1;
      value_max = 500;
      nbins = 2*(value_max-value_min);
      // G4String fileName = "./data/MySim_"+to_string(1 + ltm->tm_mon)+"_"+to_string(ltm->tm_mday)+"_"+to_string(ltm->tm_hour)+"h_"+to_string(ltm->tm_min)+"m_"+to_string(ltm->tm_sec)+"s";
      analysisManager->SetFileName(fileName+"_neutron.root");
      cout<<fileName+"_neutron.root Open"<<endl;
      analysisManager->SetVerboseLevel(1);
      analysisManager->SetActivation(true);  //enable inactivation of histograms
      ih = analysisManager->CreateH1(id, title, nbins, value_min, value_max);
      analysisManager->SetH1Activation(ih, true);
      break;
    case OTHER:
      break;
  }




  if ( analysisManager->IsActive() ) {
    analysisManager->OpenFile();
  }

}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void MyRunAction::EndOfRunAction(const G4Run* run)
{
  G4int nofEvents = run->GetNumberOfEvent();
  // if (nofEvents == 0) return;



  if(iflog==true){
    runlogfile<<"Number of Events: "<<nofEvents<<G4endl;
    runlogfile<<"----------------------------End of Run-------------------------------------"<<G4endl;
    runlogfile.close();
  }

  //G4AnalysisManager  Write&end
  G4AnalysisManager* analysisManager = G4AnalysisManager::Instance();
  if ( analysisManager->IsActive() ) {
    analysisManager->Write();
    analysisManager->CloseFile();
    cout<<analysisManager->GetFileName()+" Done!"<<endl;
  }

}



//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
