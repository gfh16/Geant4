//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
/// \file MyEventAction.cc
/// \brief Implementation of the MyEventAction class

#include "MyEventAction.hh"
#include "MyRunAction.hh"

#include "G4Event.hh"
#include "G4RunManager.hh"

#include "MyPrimaryGeneratorAction.hh"
#include <string>
#include "G4UnitsTable.hh"
#include "G4SystemOfUnits.hh"


#include "g4root.hh"

extern MySimMode_t My_Sim_mode;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

MyEventAction::MyEventAction(MyRunAction* runAction)
: G4UserEventAction(),
  fRunAction(runAction),
  fEdep(0.),fEdep_sign(1)
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

MyEventAction::~MyEventAction()
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void MyEventAction::BeginOfEventAction(const G4Event* event)
{
  fEdep = 0.;
  fEdep_sign = 1;

  if(fRunAction->iflog){
    logevent_begin_info(event);
  }

}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void MyEventAction::EndOfEventAction(const G4Event* event)
{


  if(fRunAction->iflog){
    logevent_end_info(event);
  }


  G4AnalysisManager* analysis = G4AnalysisManager::Instance();
  if(fEdep>1*MeV){
    analysis->FillH1(0, fEdep/MeV);
  }
  // analysis->FillH1(0, fEdep);

}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......


void MyEventAction::logevent_begin_info(const G4Event* event)
{
  G4int eventid = (event->GetEventID());


  G4String logstr = "eventid: "+to_string(eventid)+"\n";

  const MyPrimaryGeneratorAction* generatorAction
   = static_cast<const MyPrimaryGeneratorAction*>
     (G4RunManager::GetRunManager()->GetUserPrimaryGeneratorAction());
  if (generatorAction)
  {
    logstr +="ParticleGun: ";
    const G4ParticleGun* particleGun = generatorAction->GetParticleGun();
    logstr += particleGun->GetParticleDefinition()->GetParticleName();
    logstr += " of ";
    G4double particleEnergy = particleGun->GetParticleEnergy()/MeV;
    logstr += to_string(particleEnergy)+"MeV"+"\n";
  }



  fRunAction->runlogfile<<"<<<<<<<<==========================<event=================================="<<G4endl;
  fRunAction->runlogfile<<"=========================================================================="<<G4endl;
  fRunAction->runlogfile<<logstr<<G4endl;
}

void MyEventAction::logevent_end_info(const G4Event*)
{
  fRunAction->runlogfile<<"=========================================================================="<<G4endl;
  fRunAction->runlogfile<<"===================================event>=========================>>>>>>>>"<<G4endl;
}
