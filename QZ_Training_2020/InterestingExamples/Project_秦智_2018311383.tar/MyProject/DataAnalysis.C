#include "TH1.h"
#include "TF1.h"
#include "TMath.h"
#include "TStyle.h"
#include "TSystem.h"
#include "TLatex.h"



Double_t Nb_raw = 365;
Double_t Nb,p_Nb;  //Nb = Nb_raw*p_Nb
// Double_t beta = 0.90;
Double_t beta = 0.95;

Int_t n_of_bin = 59;
Int_t n_of_bin_Q = 60;
TH1D *hist_b = new TH1D("hist_b","hist of Background(Normalized)",n_of_bin,1,60);
TH1D *hist_sig = new TH1D("hist_sig","hist of Signal(Normalized)",n_of_bin,1,60);





Double_t Q_value(Double_t Ns,Double_t Nb,TH1D *hist_obs){
  Double_t Q = 2*Ns;
  //hist_obs->GetNbinsX() 也就是n_of_bin
  for (Int_t i_bin = 1;i_bin<=hist_obs->GetNbinsX();i_bin++){
    Double_t temp = 1;
    if(hist_b->GetBinContent(i_bin)>0&&Nb>0){
      temp = (hist_sig->GetBinContent(i_bin)/hist_b->GetBinContent(i_bin))*Ns/Nb;
    }
    else{
      temp = 0;
    }
    Q = Q - 2*hist_obs->GetBinContent(i_bin)*TMath::Log(temp+1);
  }
  return Q;
}


void Create_hist_obs(Double_t Ns,Double_t Nb,TH1D *hist_obs){
  hist_obs->FillRandom(hist_b,gRandom->Poisson(Nb));
  if(Ns>0){
    hist_obs->FillRandom(hist_sig,gRandom->Poisson(Ns));
  }
}


//得到Q_hist_b  根据back分布生成很多组hist_obs数据，然后根据hist_obs计算Q_value，从而生成Q_hist_b
void Get_Q_hist_back(TH1D *Q_hist_b,Double_t Ns,Double_t Nb) {
  TH1D *hist_obs = new TH1D("hist_obs","hist of observe",n_of_bin,1,60);
  for(Int_t i = 0;i<2000;i++){
    hist_obs->Reset();
    Create_hist_obs(0,Nb,hist_obs);
    Double_t Q = Q_value(Ns,Nb,hist_obs);
    Q_hist_b->Fill(Q);
  }
  delete hist_obs;
}

//得到Q_hist_b_s  根据back_sig分布生成很多组hist_obs数据，然后根据hist_obs计算Q_value，从而生成Q_hist_b_s
void Get_Q_hist_back_sig(TH1D *Q_hist_b_s,Double_t Ns,Double_t Nb) {
  TH1D *hist_obs = new TH1D("hist_obs","hist of observe",n_of_bin,1,60);
  for(Int_t i = 0;i<2000;i++){
    hist_obs->Reset();
    Create_hist_obs(Ns,Nb,hist_obs);
    Double_t Q = Q_value(Ns,Nb,hist_obs);
    Q_hist_b_s->Fill(Q);
  }
  delete hist_obs;
}


//根据hist_obs_true计算Ns对应的CLs值
Double_t CLs(TH1D *hist_obs_true,Double_t Ns,Double_t Nb,TH1D *Q_hist_b,TH1D *Q_hist_b_s) {
  Q_hist_b_s->Scale(1/Q_hist_b_s->Integral());
  Q_hist_b->Scale(1/Q_hist_b->Integral());
  Double_t Q_obs = Q_value(Ns,Nb,hist_obs_true);
  Double_t p_sb,p_b,cls;
  p_sb = Q_hist_b_s->Integral(Q_hist_b_s->FindBin(Q_obs),Q_hist_b_s->GetNbinsX());
  p_b = Q_hist_b->Integral(1,Q_hist_b->FindBin(Q_obs));
  cls = p_sb/(1-p_b);
  return cls;

  // for(Int_t i_bin = 1;i_bin<=Q_hist_b_s->GetNbinsX();i_bin++){
  //   if(Q_hist_b_s->GetBinCenter(i_bin)>Q_obs){
  //     p_sb = p_sb + Q_hist_b_s->GetBinContent(findbin);
  //   }
  // }
}


//变动Ns计算CLs  对每个Ns，得到Q_hist_b和Q_hist_b_s，然后计算CLs，将得到的CLs值与1-beta相比较，通过二分法调整Ns来得到Ns_up  如果CLs 太小，则变小Ns
Double_t Ns_up(TH1D *hist_obs_true,Double_t Nb,Double_t beta) {
  Double_t Ns_1 = 0,Ns_2 = 100;
  Double_t cls;
  TH1D *Q_hist_b_Ns = new TH1D("Q_hist_b_Ns","hist of Q_back (of Ns)",n_of_bin_Q,-15,15);
  TH1D *Q_hist_b_s_Ns = new TH1D("Q_hist_b_s_Ns","hist of Q_back&sig (of Ns)",n_of_bin_Q,-15,15);

  while(Ns_2-Ns_1>0.3){
    Double_t Ns_temp = (Ns_1+Ns_2)*0.5;
    Q_hist_b_Ns->Reset();
    Q_hist_b_s_Ns->Reset();
    Get_Q_hist_back(Q_hist_b_Ns,Ns_temp,Nb);
    Get_Q_hist_back_sig(Q_hist_b_s_Ns,Ns_temp,Nb);

    cls = CLs(hist_obs_true,Ns_temp,Nb,Q_hist_b_Ns,Q_hist_b_s_Ns);
    // cout<<"cls="<<cls<<"\n";

    if(cls>1-beta){
      Ns_1 = Ns_temp;
    }
    else if(cls<1-beta){
      Ns_2 = Ns_temp;
    }
    else{
      Ns_1 = Ns_temp;
      Ns_2 = Ns_temp;
    }
    // cout<<"Ns_1="<<Ns_1<<"\t"<<"Ns_2="<<Ns_2<<"\n";
  }
  delete Q_hist_b_Ns;
  delete Q_hist_b_s_Ns;
  return (Ns_1+Ns_2)*0.5;
}

//在大量纯本底事件下，beta对应的Ns_up估计的分布为
void Get_Ns_up_hist(TH1D *Ns_up_hist,Double_t Nb,Double_t beta){
  TH1D *hist_obs_true = new TH1D("hist_obs_true","hist of a true observe",n_of_bin,1,60);
  for(Int_t i = 0;i<1000;i++){
    hist_obs_true->Reset();
    Create_hist_obs(0,Nb,hist_obs_true);
    Double_t Ns_up_value = Ns_up(hist_obs_true,Nb,beta);
    Ns_up_hist->Fill(Ns_up_value);
  }
  delete hist_obs_true;
}




void DataAnalysis()
{

  //////// Part 1 ////////////////////////////////////////////////////////////////////////

  delete gRandom;
  // gRandom = new TRandom3(0);
  gRandom = new TRandom3(4869);

  //Get raw data
  TFile *file_neutron = new TFile("MySim_6_18_20h_28m_23s_neutron.root");
  // TFile *file_anti_nu_e = new TFile("MySim_6_18_18h_44m_13s_anti_nu_e.root");
  TFile *file_anti_nu_e = new TFile("MySim_6_19_18h_17m_45s_anti_nu_e.root");
  TH1D *hist_b_raw = (TH1D*)file_neutron->Get("neutron");
  TH1D *hist_sig_raw = (TH1D*)file_anti_nu_e->Get("anti_nu_e");


  // TCanvas *c1 = new TCanvas("c1","c1",0,0,1020,550);
  TCanvas *c1 = new TCanvas("c1","c1",0,0,1020,850);
  c1->SetCanvasSize(1000,800);
  c1->SetFixedAspectRatio(kTRUE);
  c1->Divide(2,2);
  c1->cd(1);


  // bin = 0; underflow bin
  // bin = 1; first bin with low-edge xlow INCLUDED
  // bin = nbins; last bin with upper-edge xup EXCLUDED
  // bin = nbins+1; overflow bin
  for(Int_t i_bin = 1;i_bin<=hist_b_raw->GetNbinsX()&&hist_b_raw->GetBinCenter(i_bin)<=60;i_bin++){
    Int_t findbin = hist_b->FindBin(hist_b_raw->GetBinCenter(i_bin));
    if(findbin>=1){
      hist_b->SetBinContent(findbin,hist_b->GetBinContent(findbin)+hist_b_raw->GetBinContent(i_bin));
    }
  }
  //本底在观测范围内的数目均值
  //hist_b_raw->GetEntries()会比hist_b_raw->Integral()稍大一点，因为包括了大于500的数
  p_Nb = hist_b->Integral()/hist_b_raw->GetEntries();
  Nb = Nb_raw*p_Nb;
  cout<<"p_Nb="<<p_Nb<<"\tNb="<<Nb<<endl;
  for(Int_t i_bin = 1;i_bin<=hist_sig_raw->GetNbinsX()&&hist_sig_raw->GetBinCenter(i_bin)<=60;i_bin++){
    Int_t findbin = hist_sig->FindBin(hist_sig_raw->GetBinCenter(i_bin));
    if(findbin>=1){
      hist_sig->SetBinContent(findbin,hist_sig->GetBinContent(findbin)+hist_sig_raw->GetBinContent(i_bin));
    }
  }

  hist_sig->Scale(1/hist_sig->Integral());
  hist_b->Scale(1/hist_b->Integral());

  hist_sig_raw->Draw("Hist");
  hist_sig_raw->GetXaxis()->SetTitle("E/(MeV)");
  // hist_sig_raw->GetXaxis()->SetTitleOffset(1.1);
  hist_sig_raw->GetYaxis()->SetTitle("N");
  // hist_sig_raw->GetYaxis()->SetTitleOffset(1.1);
  c1->cd(2);
  hist_b_raw->Draw("Hist");
  hist_b_raw->GetXaxis()->SetTitle("E/(MeV)");
  hist_b_raw->GetYaxis()->SetTitle("N");
  c1->cd(3);
  hist_sig->Draw("Hist");
  hist_sig->GetXaxis()->SetTitle("E/(MeV)");
  // hist_sig->GetYaxis()->SetTitle("f(E)");
  // hist_sig->GetYaxis()->SetTitleOffset(0.8);
  c1->cd(4);
  hist_b->Draw("Hist");
  hist_b->GetXaxis()->SetTitle("E/(MeV)");
  // hist_b->GetYaxis()->SetTitle("f(E)");
  // hist_b->GetYaxis()->SetTitleOffset(0.8);
  c1->Modified();
  c1->SaveAs("Energy_Distribution.png");


  //////// Part 2 ////////////////////////////////////////////////////////////////////////



  //随机产生一个纯本底事件下（一年），给出beta对应的Ns_up估计
  TH1D *hist_obs_true = new TH1D("hist_obs_true",TString::Format("hist of a true observe(Ns=0,Nb=%.2f)",Nb),n_of_bin,1,60);
  Create_hist_obs(0,Nb,hist_obs_true);
  Double_t Ns_up_value = Ns_up(hist_obs_true,Nb,beta);
  Double_t Q_obs = Q_value(Ns_up_value,Nb,hist_obs_true);

  TH1D *Q_hist_b_Ns = new TH1D("Q_hist_b_Ns","hist of Q_{back} (of Ns)",n_of_bin_Q,-15,15);
  TH1D *Q_hist_b_s_Ns = new TH1D("Q_hist_b_s_Ns","hist of Q_{back&sig} (of Ns)",n_of_bin_Q,-15,15);
  Get_Q_hist_back(Q_hist_b_Ns,Ns_up_value,Nb);
  Get_Q_hist_back_sig(Q_hist_b_s_Ns,Ns_up_value,Nb);

  Double_t cls = CLs(hist_obs_true,Ns_up_value,Nb,Q_hist_b_Ns,Q_hist_b_s_Ns);

  cout<<"cls = "<<cls<<endl;
  cout<<"Q_obs = "<<Q_obs<<endl;
  cout<<"Ns_up_value = "<<Ns_up_value<<endl;

  TCanvas *c2 = new TCanvas("c2","c2",0,0,1020,550);
  c2->SetCanvasSize(1000,500);
  c2->SetFixedAspectRatio(kTRUE);
  c2->Divide(2);
  c2->cd(1);
  hist_obs_true->Draw("Hist");
  hist_obs_true->GetXaxis()->SetTitle("E/(MeV)");
  hist_obs_true->GetXaxis()->SetTitleOffset(1.1);
  hist_obs_true->GetYaxis()->SetTitle("N");
  hist_obs_true->GetYaxis()->SetTitleOffset(1.1);
  c2->cd(2);
  Q_hist_b_Ns->Draw();
  Q_hist_b_s_Ns->Draw("HistSAMES");


  Q_hist_b_Ns->Draw("Hist");
  Q_hist_b_Ns->SetLineColor(kRed);
  Q_hist_b_Ns->SetTitle("Q_{back} & Q_{back&sig} (Ns=Ns_{up})");
  Q_hist_b_Ns->GetXaxis()->SetTitle("Q=-2ln(L_{s+b}/L_{b})");
  Q_hist_b_Ns->GetXaxis()->SetTitleOffset(1.1);
  Q_hist_b_Ns->GetYaxis()->SetTitle("f_{Q}");
  Q_hist_b_Ns->GetYaxis()->SetTitleOffset(1.1);
  gPad->Update();
  TPaveStats *statsbox = (TPaveStats*)gPad->GetPrimitive("stats");
  Double_t y1 = statsbox->GetY1NDC(); // (lower) y start position of stats box
  statsbox->SetY1NDC(2*statsbox->GetY1NDC()-statsbox->GetY2NDC());    //set new y start position
  statsbox->SetY2NDC(y1);    //set new y end position

  Q_hist_b_s_Ns->Draw("HistSAMES");
  Q_hist_b_s_Ns->SetLineColor(kGreen);

  TLegend *l2  = new TLegend(0.1,0.8,0.2,0.9);//xmin ymin xmax ymax
  l2->AddEntry(Q_hist_b_Ns,"Q_b","l");
  l2->AddEntry(Q_hist_b_s_Ns,"Q_b_s","l");
  l2->Draw();

  // string text_str = "#splitline{Ns = "+to_string(Ns_up_value)+"}{Q_obs = "+to_string(Q_obs)+"}";
  // const char *str=text_str.c_str();
  // cout<<"str="<<str<<endl;
  // TLatex text(0.5,0.5,"str");
  // text.Draw();
  // auto t1 = new TLatex(-2.5, 300000, TString::Format("%s = %8.0f #pm %4.0f", "NSignal",Ns_up_value, Q_obs ) ,"NDC");
  // t1->SetTextFont(62);
  // t1->Draw();

  TPaveText *pt =new TPaveText(.1,.6,.3,.8,"brNDC");
  pt->AddText(TString::Format("%s = %.2f", "Ns_{up}",Ns_up_value));
  pt->AddText(TString::Format("%s = %.2f", "Nb",Nb));
  pt->AddText(TString::Format("%s = %.2f", "Q_{obs}",Q_obs));
  pt->AddText(TString::Format("%s = %.2f", "CLs",cls));
  pt->SetLabel("Result");
  pt->Draw();

  TLine *line = new TLine(Q_obs,0,Q_obs,gPad->GetUymax());
  line->SetLineColor(kBlue);
  line->Draw();

  c2->Modified();

  c2->SaveAs(TString::Format("A_True_Obs_and_its_Ns(beta=0_%d).png",int(beta*100)));


  //////// Part 3 ////////////////////////////////////////////////////////////////////////

  delete hist_obs_true;
  delete Q_hist_b_Ns;
  delete Q_hist_b_s_Ns;


  TCanvas *c3 = new TCanvas("c3","c3",0,0,820,850);
  c3->SetCanvasSize(800,800);
  c3->SetFixedAspectRatio(kTRUE);
  c3->cd(1);
  //在大量纯本底事件下，beta对应的Ns_up估计的分布为
  TH1D *Ns_up_hist = new TH1D("Ns_up_hist","hist of a Ns_{up}(of Ns_{real}=0)",50,10,50);
  Get_Ns_up_hist(Ns_up_hist,Nb,beta);
  Ns_up_hist->Draw("Hist");
  Ns_up_hist->GetXaxis()->SetTitle("Ns_{up}");
  Ns_up_hist->GetXaxis()->SetTitleOffset(1.1);
  Ns_up_hist->GetYaxis()->SetTitle("N");
  Ns_up_hist->GetYaxis()->SetTitleOffset(1.1);

  // TPaveText *pt3 =new TPaveText(.1,.8,.25,.9,"brNDC");
  TPaveText *pt3 =new TPaveText(.1,.84,.2,.9,"brNDC");
  pt3->AddText(TString::Format("#beta = %.2f",beta));
  pt3->Draw();

  c3->Modified();

  c3->SaveAs(TString::Format("Ns_up_Distribution(beta=0_%d).png",int(beta*100)));












  // gStyle->SetOptStat(1111);

  //
  // f1_mu->Draw();
  // f1_mu->SetTitle("mu(free)");
  // c1->cd(2);
  // f1_sigma->Draw();
  // f1_sigma->SetLineColor(kRed);
  // f1_sigma->SetTitle("sigma");
  // gPad->Update();
  // TPaveStats *statsbox = (TPaveStats*)gPad->GetPrimitive("stats");
  // // get (default) y position of stats box (histo h1)
  // double y1 = statsbox->GetY1NDC(); // (lower) y start position of stats box
  // double y2 = statsbox->GetY2NDC(); // (upper) y start position of stats box
  // // set new position of stats box (histo h1)
  // double newy1 = 2 * y1 - y2;   // new (lower) y start position of stats box
  // double newy2 = y1;            // new (upper) y start position of stats box
  // statsbox->SetY1NDC(newy1);    //set new y start position
  // statsbox->SetY2NDC(newy2);    //set new y end position
  //
  // f2_sigma->Draw("sames");
  // f2_sigma->SetLineColor(kGreen);
  // // Draw options:
  // // "same"  : draw histogram on same canvas, do not redraw stats box
  // // "sames" : draw histogram on same canvas, draw stats box (in default position)
  //
  // TLegend *l1  = new TLegend(0.5,0.5,0.7,0.7);
  // l1->AddEntry(f1_sigma,"#mu free","l");
  // l1->AddEntry(f2_sigma,"#mu=0.05","l");
  // l1->Draw();
  //
  // // TPaveStats *ps1 = (TPaveStats*)f1_sigma->GetListOfFunctions()->FindObject("stats");
  // // ps1->SetX1NDC(0.4); ps1->SetX2NDC(0.6);
  // c1->Modified();
  //
  //
  // c1->cd(3);
  // f1_chi2ndf->Draw();
  // f1_chi2ndf->SetLineColor(kRed);
  // f1_chi2ndf->SetTitle("chi2ndf");
  // gPad->Update();
  // statsbox = (TPaveStats*)gPad->GetPrimitive("stats");
  // // get (default) y position of stats box (histo h1)
  // y1 = statsbox->GetY1NDC(); // (lower) y start position of stats box
  // statsbox->SetY1NDC(2*statsbox->GetY1NDC()-statsbox->GetY2NDC());    //set new y start position
  // statsbox->SetY2NDC(y1);    //set new y end position
  //
  // f2_chi2ndf->Draw("sames");
  // f2_chi2ndf->SetLineColor(kGreen);
  // // c1->SetTitle("AAA");
  // // gPad->SetTitle("BBB");
  //
  // TLegend *l2  = new TLegend(0.5,0.5,0.7,0.7);
  // l2->AddEntry(f1_chi2ndf,"#mu free","l");
  // l2->AddEntry(f2_chi2ndf,"#mu=0.05","l");
  // l2->Draw();
  //
  // c1->Modified();
  //
  //
  //
  //
  // c1->SaveAs("Hw7.png");
}
